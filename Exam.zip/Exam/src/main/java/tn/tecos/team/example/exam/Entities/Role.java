package tn.tecos.team.example.exam.Entities;

public enum Role {
    SCRUM_MASTER,
    PRODUCT_OWNER,
    DEVELOPER,
    CLIENT
}
