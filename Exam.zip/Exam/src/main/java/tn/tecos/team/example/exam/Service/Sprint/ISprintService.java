package tn.tecos.team.example.exam.Service.Sprint;

import tn.tecos.team.example.exam.Entities.Sprint;

public interface ISprintService {
    public Sprint addSprint (Sprint sprint);
}
