package tn.tecos.team.example.exam.Service.Projet;

import tn.tecos.team.example.exam.Entities.Projet;

public interface IProjetService {
    public Projet addProject (Projet project);
}
