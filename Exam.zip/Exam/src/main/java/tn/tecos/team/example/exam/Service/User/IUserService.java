package tn.tecos.team.example.exam.Service.User;

import tn.tecos.team.example.exam.Entities.User;

public interface IUserService {
    User addUser(User e);
}
